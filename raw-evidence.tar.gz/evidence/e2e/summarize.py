"""Summarize retained evidence; never infer backend kernel speed from TPOT."""
import json,pathlib,statistics,sys
root=pathlib.Path(sys.argv[1])
def read(p):return json.loads(p.read_text())
def quantiles(v):
 v=sorted(v)
 if not v:return None
 return {'n':len(v),'mean':statistics.mean(v),'p50':v[round((len(v)-1)*.5)],'p95':v[round((len(v)-1)*.95)],'max':v[-1]}
runs=[]
for result_file in sorted(root.glob('*/result.json')):
 result=read(result_file)
 if 'arm' not in result:continue
 p=result_file.parent
 rows=[read(f)['result'] for f in p.glob('request-*.json')]
 before=read(p/'before.json')['backends'];after=read(p/'after.json')['backends']
 starts=[r['start_wall'] for r in rows];start=min(starts)
 samples=[json.loads(line) for line in (p/'metrics.jsonl').read_text().splitlines()]
 backend=[]
 for first,last in zip(before,after):
  url=first['url'];bm=first['metrics'];am=last['metrics']
  delta={k:am.get(k,0)-bm.get(k,0) for k in ('vllm:request_success_total','vllm:prompt_tokens_total','vllm:generation_tokens_total','vllm:prefix_cache_hits_total','vllm:external_prefix_cache_hits_total')}
  series=[(s['time'],next(x for x in s['backends'] if x['url']==url).get('metrics',{})) for s in samples]
  active=[t-start for t,m in series if m.get('vllm:num_requests_running',0) or m.get('vllm:num_requests_waiting',0)]
  completion=[t-start for t,m in series if m.get('vllm:request_success_total',0)>=am.get('vllm:request_success_total',0)]
  backend.append({'url':url,'delta':delta,'peak_running':max((m.get('vllm:num_requests_running',0) for _,m in series),default=0),'peak_waiting':max((m.get('vllm:num_requests_waiting',0) for _,m in series),default=0),'last_active_sample_s':max(active,default=None),'all_completions_observed_s':min(completion,default=None) if delta['vllm:request_success_total'] else None})
 classes={}
 for cls in sorted({r['class'] for r in rows}):
  subset=[r for r in rows if r['class']==cls]
  classes[cls]={key:quantiles([r[key] for r in subset if r.get(key) is not None]) for key in ('ttft','tpot','latency')}
 runs.append({'result':result,'backend':backend,'classes':classes})
(root/'summary.json').write_text(json.dumps(runs,indent=2))
print('run | success | TPS | TTFT p50/p95(s) | TPOT p50/p95(ms) | P request counts | D request counts')
for r in runs:
 d=r['result'];t=d['ttft'];o=d['tpot'];counts=[int(x['delta']['vllm:request_success_total']) for x in r['backend']]
 print(f"{d['run']} | {d['success']}/{d['concurrency']} | {d['output_tokens_per_second']:.2f} | {t['p50']:.2f}/{t['p95']:.2f} | {o['p50']*1000:.2f}/{o['p95']*1000:.2f} | {counts[:4]} | {counts[4:]}")
print('Prefix cache hits and external transferred KV hits are separate counters. TPOT is observed service latency, not isolated kernel throughput. Tail quantiles are descriptive for these sample sizes.')
