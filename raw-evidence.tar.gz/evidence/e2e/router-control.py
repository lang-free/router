import os,sys,pathlib,subprocess,json,time,urllib.request,hashlib
R=pathlib.Path('/data/glm53flash-nightly-20261009/capacity-256k-v1/router-performance-20261015')
arm=sys.argv[1];assert arm in ('candidate','final')
name='glm53-router-paired'
old=subprocess.run(['docker','inspect',name],capture_output=True,text=True)
if old.returncode==0:
 info=json.loads(old.stdout)[0];assert info['Config']['Labels'].get('experiment')=='router-paired-20261018'
 subprocess.run(['docker','stop','-t','20',name],check=True,stdout=subprocess.DEVNULL)
 subprocess.run(['docker','rm',name],check=True,stdout=subprocess.DEVNULL)
original=json.loads(subprocess.check_output(['docker','inspect','glm53-rc2-router']))[0]
args=list(original['Args'])
for key,val in {'--host':'127.0.0.1','--port':'18102','--prefill-policy':'consistent_hash','--decode-policy':os.environ.get('D_POLICY','cache_aware'),'--balance-abs-threshold':('32' if os.environ.get('D_POLICY','cache_aware')=='cache_aware' else '0'),'--balance-rel-threshold':'1.1','--health-check-interval-secs':'3600','--prometheus-port':'19192'}.items():args[args.index(key)+1]=val
# Both arms use the same upstream policy and avoid the separate periodic-load-reset bug.
binary=R/f'vllm-router-{arm}' if arm=='candidate' else R.parent/'router-d-final-20261018/vllm-router-final'
meta={'arm':arm,'args':args,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'time':time.time()}
cmd=['docker','run','-d','--name',name,'--label','experiment=router-paired-20261018','--network','host','--cpus','8','--memory','4g','--log-opt','max-size=10m','--log-opt','max-file=3','-v',str(R.parent)+':/trial:ro','-e','NO_PROXY=*','-e','no_proxy=*','--entrypoint','/trial/'+str(binary.relative_to(R.parent)),original['Image']]+args
subprocess.run(cmd,check=True,stdout=subprocess.DEVNULL)
pathlib.Path('/data/glm53flash-rc2-20261018/router-isolated/router-launches.jsonl').open('a').write(json.dumps(meta)+'\n')
op=urllib.request.build_opener(urllib.request.ProxyHandler({}))
for _ in range(120):
 try:
  with op.open('http://127.0.0.1:18102/workers',timeout=3) as resp:workers=json.load(resp)['workers']
  if len(workers)==12 and all(x['is_healthy'] for x in workers):print('ROUTER_READY',arm);break
 except Exception:pass
 time.sleep(1)
else:raise RuntimeError('router not ready')
