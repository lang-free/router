import pathlib,subprocess,os,time,json
R=pathlib.Path('/data/glm53flash-rc2-20261018/router-isolated');T='/deploy/router-isolated'
def log(*a):print(time.strftime('%FT%T'),*a,flush=True)
def router(arm):subprocess.run(['python3',str(R/'router-control.py'),arm],check=True,timeout=180)
def run(arm,name,fixture,mode,namespace):
 data=json.loads((R/'fixtures'/f'{fixture}.json').read_text());n=len(data['requests']);nt=max(data['input_lengths']);nout=data['requests'][0]['max_tokens']
 log('START',name)
 with (R/(name+'.log')).open('w') as f:
  subprocess.run(['docker','exec','-e','FIXTURE='+fixture,'-e','CACHE_NAMESPACE='+namespace,'-e','REVIEW_MODE='+mode,'glm53-rc2-pd','python3',T+'/benchmark.py',arm,name,str(nt),str(n),str(nout),'true'],stdout=f,stderr=subprocess.STDOUT,check=True,timeout=900)
 d=json.loads((R/'results'/name/'result.json').read_text());log('DONE',name,d['success'],'TPS',round(d['output_tokens_per_second'],2))
def validate_pair(label,rep):
 a=R/'results'/f'{label}-r{rep}-candidate';b=R/'results'/f'{label}-r{rep}-final'
 assert (a/'fixture.json').read_bytes()==(b/'fixture.json').read_bytes(),'fixture mismatch'
 files=sorted(a.glob('body-*.json'));assert len(files)==len(list(b.glob('body-*.json')))
 for f in files:
  x=json.loads(f.read_text());y=json.loads((b/f.name).read_text());x.pop('cache_salt');y.pop('cache_salt');assert x==y,'request mismatch'
 def p_counts(d):
  before=json.loads((d/'before.json').read_text())['backends'][:4];after=json.loads((d/'after.json').read_text())['backends'][:4]
  return {b['url']:a['metrics'].get('vllm:request_success_total',0)-b['metrics'].get('vllm:request_success_total',0) for b,a in zip(before,after)}
 assert p_counts(a)==p_counts(b), 'P placement counts differ; no causal comparison'
 (R/'pairs.jsonl').open('a').write(json.dumps({'workload':label,'repeat':rep,'request_bodies_identical_except_cache_salt':True,'count':len(files)})+'\n')
try:
 probe=pathlib.Path('/data/glm53flash-nightly-20261009/capacity-256k-v1/router-isolated-probe-20261018/probe.exit')
 log('WAITING_FOR_LOCK_PROBE')
 while not probe.exists():time.sleep(10)
 assert probe.read_text().strip()=='0', 'lock probe failed; do not run E2E'
 for arm in ['candidate','final']:
  router(arm)
  # Keep this router running for the entire arm, including all warmup and measured cases.
  for w in range(1,3):
   for label,mode in [('ordinary','cold'),('mixed','mixed_lengths'),('warm','warm')]:
    ns=f'isolated-v1-prewarm-{w}-{label}-{arm}'
    if label=='warm':run(arm,f'prewarm-prime-{w}-{arm}','prime','prime',ns)
    run(arm,f'prewarm-{label}-{w}-{arm}',label,mode,ns)
  for rep in range(1,3):
   for label,mode in [('ordinary','cold'),('mixed','mixed_lengths'),('warm','warm')]:
    ns=f'isolated-v1-{label}-r{rep}-{arm}'
    if label=='warm':run(arm,f'prime-r{rep}-{arm}','prime','prime',ns)
    run(arm,f'{label}-r{rep}-{arm}',label,mode,ns)
  (R/f'router-{arm}.log').write_text(subprocess.check_output(['docker','logs','glm53-router-paired'],stderr=subprocess.STDOUT,text=True))
 for rep in range(1,3):
  for label in ['ordinary','mixed','warm']:validate_pair(label,rep)
 (R/'exit').write_text('0\n');log('COMPLETE')
except Exception as e:
 (R/'exit').write_text('1\n');log('HALTED',repr(e));raise
finally:
 with (R/'summary.txt').open('w') as f:subprocess.run(['python3',str(R/'summarize.py'),str(R/'results')],stdout=f,stderr=subprocess.STDOUT)
