import os
import asyncio, json, time, pathlib, hashlib, random, statistics, sys
import aiohttp
from transformers import AutoTokenizer
ROOT=pathlib.Path('/deploy/router-isolated/results')
BACKENDS=[f'http://10.29.1.{n}:{p}' for n in (1,2,3,4) for p in ([19081,19082] if n<3 else range(19900,19904))]
METRICS=('num_requests_running','num_requests_waiting','kv_cache_usage_perc','request_success_total','generation_tokens_total','prompt_tokens_total','prefix_cache_hits_total','external_prefix_cache_hits_total','request_queue_time_seconds_sum','request_prefill_time_seconds_sum','request_decode_time_seconds_sum','request_inference_time_seconds_sum','request_time_per_output_token_seconds_sum')
def parse_metrics(text):
 out={}
 for line in text.splitlines():
  if line.startswith('#'):continue
  name=line.split('{')[0].split(' ')[0]
  if name.removeprefix('vllm:') in METRICS:
   try:out[name]=out.get(name,0)+float(line.rsplit(' ',1)[1])
   except ValueError:pass
 return out
async def snapshot(s):
 async def one(url):
  try:
   async with s.get(url+'/metrics',timeout=aiohttp.ClientTimeout(total=5)) as r: m=parse_metrics(await r.text())
   async with s.get(url+'/health',timeout=aiohttp.ClientTimeout(total=5)) as r: safety={'ready':r.status==200,'fenced':r.status!=200}
   return {'url':url,'metrics':m,'ready':safety.get('ready'),'fenced':safety.get('fenced')}
  except Exception as e:return {'url':url,'error':repr(e)}
 return await asyncio.gather(*(one(x) for x in BACKENDS))
def idle(rows):return all(x.get('ready') and x.get('fenced') is False and x.get('metrics') and x['metrics'].get('vllm:num_requests_running',-1)==0 and x['metrics'].get('vllm:num_requests_waiting',-1)==0 for x in rows)
async def wait_idle(s):
 for _ in range(120):
  rows=await snapshot(s)
  if idle(rows):return rows
  if any(x.get('fenced') for x in rows):raise RuntimeError('backend fenced')
  await asyncio.sleep(1)
 raise RuntimeError('backends did not become idle')
def stats(vals):
 vals=sorted(vals)
 if not vals:return None
 def q(p):return vals[min(len(vals)-1,int((len(vals)-1)*p+0.5))]
 return {'n':len(vals),'mean':statistics.mean(vals),'p50':q(.5),'p90':q(.90),'p95':q(.95),'p99':q(.99),'min':vals[0],'max':vals[-1]}
async def main():
 arm,run,ntok,nreq,nout,stream=sys.argv[1:];ntok,nreq,nout=int(ntok),int(nreq),int(nout);stream=stream=='true'
 out=ROOT/run;out.mkdir(exist_ok=False)
 fixture_path=pathlib.Path('/deploy/router-isolated/fixtures')/(os.environ['FIXTURE']+'.json')
 fixture_bytes=fixture_path.read_bytes();fixture=json.loads(fixture_bytes)
 bodies=fixture['requests'];assert len(bodies)==nreq
 prompts=[x['prompt'] for x in bodies];input_lengths=fixture['input_lengths'];classes=fixture['classes']
 mode=os.environ.get('REVIEW_MODE','cold');scope=os.environ['CACHE_NAMESPACE']
 (out/'fixture.json').write_bytes(fixture_bytes)
 cfg={'arm':arm,'run':run,'input_tokens':ntok,'concurrency':nreq,'output_tokens':nout,'stream':stream,'mode':mode,'scope':scope,'expected_input_tokens':input_lengths,'fixture':fixture_path.name}
 (out/'config.json').write_text(json.dumps(cfg,indent=2))
 async with aiohttp.ClientSession(connector=aiohttp.TCPConnector(limit=100),trust_env=False) as s:
  before=await wait_idle(s)
  async with s.get('http://127.0.0.1:18102/workers') as r: wb=await r.json()
  (out/'before.json').write_text(json.dumps({'backends':before,'workers':wb}))
  stop=asyncio.Event(); fatal=[]
  async def monitor():
   with (out/'metrics.jsonl').open('w') as f:
    while not stop.is_set():
     rows=await snapshot(s)
     if any(x.get('fenced') for x in rows):fatal.append('backend fenced')
     try:
      async with s.get('http://127.0.0.1:18102/workers',timeout=aiohttp.ClientTimeout(total=5)) as r:w=await r.json()
     except Exception as e:w={'error':repr(e)}
     f.write(json.dumps({'time':time.time(),'backends':rows,'workers':w})+'\n');f.flush()
     await asyncio.sleep(2)
  gate=asyncio.Event()
  async def request(i,ids):
   body={**bodies[i],'cache_salt':scope}
   (out/f'body-{i}.json').write_text(json.dumps(body))
   await gate.wait();start=time.monotonic();row={'i':i,'class':classes[i],'input_tokens':input_lengths[i],'output_tokens':nout,'start_wall':time.time(),'status':None,'ttft':None,'usage':None,'done':False};chunks=[];text='';last=None;intervals=[]
   try:
    async with s.post('http://127.0.0.1:18102/v1/completions',json=body,headers={'X-Request-Id':f'rperf-{run}-{i}', 'X-Session-Id':f'isolated-slot-{i%4 if mode in ("prime","warm") else i}'},timeout=aiohttp.ClientTimeout(total=600)) as r:
     row['status']=r.status;row['headers_seconds']=time.monotonic()-start
     if r.status!=200:row['error']=await r.text()
     elif not stream:
      data=await r.json();row['usage']=data.get('usage');row['done']=bool(data.get('choices'));row['response']=data
     else:
      async for line in r.content:
       line=line.strip()
       if not line.startswith(b'data:'):continue
       payload=line[5:].strip()
       if payload==b'[DONE]':row['done']=True;break
       data=json.loads(payload);now=time.monotonic();chunks.append({'elapsed':now-start,'data':data})
       if data.get('error'):row['error']=data['error']
       if data.get('usage'):row['usage']=data['usage']
       for choice in data.get('choices',[]):
        value=choice.get('text','')
        if value:
         if row['ttft'] is None:row['ttft']=now-start
         if last is not None:intervals.append(now-last)
         last=now;text+=value
   except Exception as e:row['error']=repr(e)
   row['latency']=time.monotonic()-start;row['text']=text;row['chunk_intervals']=stats(intervals)
   count=(row['usage'] or {}).get('completion_tokens')
   if count and count>1 and row['ttft'] is not None:row['tpot']=(last-start-row['ttft'])/(count-1)
   (out/f'request-{i}.json').write_text(json.dumps({'result':row,'chunks':chunks}))
   return row
  mon=asyncio.create_task(monitor())
  if mode=='prime':
   gate.set();start=time.monotonic();rows=[]
   for i,p in enumerate(prompts):rows.append(await request(i,p))
  else:
   tasks=[asyncio.create_task(request(i,p)) for i,p in enumerate(prompts)]
   await asyncio.sleep(.2);start=time.monotonic();gate.set();rows=await asyncio.gather(*tasks)
  elapsed=time.monotonic()-start
  try:after=await wait_idle(s)
  except Exception as e:
   fatal.append('post-run drain: '+repr(e));after=await snapshot(s)
  stop.set();await mon
  async with s.get('http://127.0.0.1:18102/workers') as r: wa=await r.json()
  (out/'after.json').write_text(json.dumps({'backends':after,'workers':wa}))
  good=[r for r in rows if r['status']==200 and r['done'] and not r.get('error') and (r.get('usage') or {}).get('prompt_tokens')==r['input_tokens'] and (r.get('usage') or {}).get('completion_tokens')==nout]
  total=sum((r['usage'] or {}).get('completion_tokens',0) for r in good)
  result={**cfg,'success':len(good),'wall_seconds':elapsed,'output_tokens_actual':total,'output_tokens_per_second':total/elapsed,'ttft':stats([r['ttft'] for r in good if r['ttft'] is not None]),'latency':stats([r['latency'] for r in good]),'tpot':stats([r['tpot'] for r in good if 'tpot' in r]),'fatal':fatal}
  result['cache_deltas']=[{'url':new['url'],'prefix_hits':new.get('metrics',{}).get('vllm:prefix_cache_hits_total',0)-old.get('metrics',{}).get('vllm:prefix_cache_hits_total',0)} for old,new in zip(before,after)]
  if mode in ('cold','mixed_lengths') and any(x['prefix_hits']!=0 for x in result['cache_deltas']):fatal.append('cold cache namespace not isolated')
  if mode=='warm' and sum(x['prefix_hits'] for x in result['cache_deltas'][:4])<=0:fatal.append('warm workload had no P prefix hits')
  (out/'result.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
  if len(good)!=nreq or fatal:raise RuntimeError('Invalid run; inspect evidence')
asyncio.run(main())
