use std::{cell::Cell,time::Instant};
thread_local! {static COUNTS:Cell<(f64,f64)>=const{Cell::new((0.0,0.0))};}
pub fn reset(){COUNTS.with(|c|c.set((0.0,0.0)));}
pub fn read()->(f64,f64){COUNTS.with(|c|c.get())}
#[derive(Debug,Default)]
pub struct ProbeLock(parking_lot::Mutex<()>);
pub struct Held<'a>{guard:Option<parking_lot::MutexGuard<'a,()>>,start:Instant}
impl ProbeLock {pub fn lock(&self)->Held<'_>{let t=Instant::now();let guard=self.0.lock();let now=Instant::now();COUNTS.with(|c|{let(w,h)=c.get();c.set((w+now.duration_since(t).as_secs_f64()*1e6,h));});Held{guard:Some(guard),start:now}}}
impl Drop for Held<'_>{fn drop(&mut self){let held=self.start.elapsed().as_secs_f64()*1e6;drop(self.guard.take());COUNTS.with(|c|{let(w,h)=c.get();c.set((w,h+held));});}}
