use std::sync::{Arc,Barrier};
use std::time::Instant;
use vllm_router_rs::core::{BasicWorker,Worker,WorkerLoadGuard,WorkerType};
use vllm_router_rs::policies::{CacheAwareConfig,CacheAwarePolicy,LoadBalancingPolicy};
use vllm_router_rs::probe_clock::{ProbeLock,reset,read};

fn main(){
 println!("arm,case,cache,concurrency,repeat,id,bytes,wait_us,hold_us,total_us,worker");
 for case in ["short","long","mixed"] {for cache in ["cold","warm"] {for n in [1,8,32] {for rep in 0..10 {
  let ws:Vec<Arc<dyn Worker>>=(0..8).map(|i|Arc::new(BasicWorker::new(format!("http://d-{i}"),WorkerType::Decode)) as Arc<dyn Worker>).collect();
  let p=CacheAwarePolicy::with_config(CacheAwareConfig{eviction_interval_secs:0,..Default::default()}); p.init_workers(&ws);
  let texts:Vec<String>=(0..n).map(|i| {let len=if case=="short" || (case=="mixed" && i%2==1){4096}else{1048576}; format!("{:08}",i)+"a".repeat(len-8).as_str()}).collect();
  if cache=="warm" {for t in &texts {p.select_worker_with_headers(&ws,Some(t),None).unwrap();}}
  let context=ProbeLock::default();
  let start=Barrier::new(n);let reserved=Barrier::new(n);let checked=Barrier::new(n);
  let rows=std::thread::scope(|scope|{let mut hs=Vec::new();
   for i in 0..n {let (ws,p,texts,start,reserved,checked,context)=(&ws,&p,&texts,&start,&reserved,&checked,&context);
    hs.push(scope.spawn(move||{reset();start.wait();let t=Instant::now();
     let held=context.lock();let idx=p.select_worker_with_headers(ws,Some(&texts[i]),None).unwrap();let guard=WorkerLoadGuard::new(ws[idx].as_ref());drop(held);
     let total=t.elapsed().as_secs_f64()*1e6;let (wait,hold)=read();
     reserved.wait();assert_eq!(ws.iter().map(|w|w.load()).sum::<usize>(),n);checked.wait();drop(guard);
     (i,texts[i].len(),wait,hold,total,idx)
    }));
   }hs.into_iter().map(|h|h.join().unwrap()).collect::<Vec<_>>()});
  assert!(ws.iter().all(|w|w.load()==0));
  for (i,bytes,wait,hold,total,idx) in rows {println!("candidate,{case},{cache},{n},{rep},{i},{bytes},{wait},{hold},{total},{idx}");}
 }}}}
}
