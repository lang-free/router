set -eu
export CARGO_HOME=/trial/qos-20261010/router-build/cargo RUSTUP_HOME=/trial/qos-20261010/router-build/rustup
export PATH=$CARGO_HOME/bin:$PATH
export CARGO_TARGET_DIR=/trial/qos-20261010/router-build/source/target
export OPENSSL_LIB_DIR=/trial/pr-router-reservation-20261013/deps/root/usr/lib/aarch64-linux-gnu
export OPENSSL_INCLUDE_DIR=/trial/pr-router-reservation-20261013/deps/root/usr/include
export CFLAGS=-I/trial/pr-router-reservation-20261013/deps/root/usr/include/aarch64-linux-gnu
export LD_LIBRARY_PATH=$OPENSSL_LIB_DIR
p=/trial/router-isolated-probe-20261018
trap 'echo $? > "$p/probe.exit"' EXIT
for arm in candidate final; do
 cd "$p/$arm"
 cargo +1.95.0 build --offline --locked --release --bin isolated_probe -j4 > "$p/$arm-build.log" 2>&1
 cp "$CARGO_TARGET_DIR/release/isolated_probe" "$p/isolated-probe-$arm"
 "$p/isolated-probe-$arm" > "$p/$arm.csv" 2> "$p/$arm-run.log"
done
