    #[tokio::test]
    async fn prefill_selection_is_invisible_during_encoder_prepare() {
        let entered=Arc::new(tokio::sync::Semaphore::new(0));let signal=entered.clone();
        let encoder=spawn_test_server(axum::Router::new().fallback(move || {let signal=signal.clone();async move {signal.add_permits(1);std::future::pending::<StatusCode>().await}})).await;
        let prefill:Arc<dyn Worker>=Arc::new(BasicWorker::new("http://127.0.0.1:1".into(),WorkerType::Prefill{bootstrap_port:None}));
        let decode:Arc<dyn Worker>=Arc::new(BasicWorker::new("http://127.0.0.1:2".into(),WorkerType::Decode));
        let mut router=test_vllm_pd_router();
        router.epd=Some(super::super::epd::EncoderStage::new(crate::config::EpdConfig{encoder_urls:vec![encoder],consumer_zmq_addrs:Default::default()}));
        router.pd_router.worker_registry.register(prefill.clone());router.pd_router.worker_registry.register(decode.clone());let router=Arc::new(router);
        let mut tasks=Vec::new();
        for _ in 0..24 {let router=router.clone();tasks.push(tokio::spawn(async move {router.route_chat(None,&serde_json::from_value(json!({"model":"test","messages":[{"role":"user","content":[{"type":"image_url","image_url":{"url":"data:image/png;base64,abc"}},{"type":"text","text":"describe"}]}],"stream":true})).unwrap(),None).await}));}
        tokio::time::timeout(std::time::Duration::from_secs(10),entered.acquire_many(24)).await.unwrap().unwrap().forget();
        println!("PREFILL_WINDOW: encoder_pending=24 prefill_load={} decode_load={}",prefill.load(),decode.load());
        assert_eq!(prefill.load(),0);assert_eq!(decode.load(),24);
        for task in &tasks {task.abort();}for task in tasks {let _=task.await;}
        assert_eq!(prefill.load(),0);assert_eq!(decode.load(),0);
    }
